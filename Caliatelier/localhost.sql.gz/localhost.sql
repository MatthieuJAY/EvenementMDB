-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `MDB` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `MDB`;

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `events` (`id`, `title`, `location`, `date`, `time`, `image`, `description`) VALUES
(1,	'test',	'per',	'2012-12-21',	'12:22:00',	'https://www.infolocale.fr/blog/wp-content/uploads/2021/11/organiser-vide-greniers.jpg',	'test'),
(2,	'fegegre',	'dezzfdaf',	'2000-12-21',	'15:59:00',	'https://img.20mn.fr/N-CM1EgSTJaHDsiqOP3fbg/310x190_vide-grenier-commune-sarthe-2011',	'aegytythrgrfcdsx'),
(3,	'fegegre',	'dezzfdaf',	'0205-12-21',	'15:59:00',	'https://img.20mn.fr/N-CM1EgSTJaHDsiqOP3fbg/310x190_vide-grenier-commune-sarthe-2011',	'aegytythrgrfcdsx'),
(4,	'Essai 24',	'same',	'2023-02-14',	'12:00:00',	'',	'defez'),
(5,	'test 5',	'same2',	'2023-02-02',	'15:00:00',	'',	'aeffzergz'),
(6,	'zafezg',	'same4',	'2023-01-22',	'20:00:00',	'',	'hehe'),
(7,	'Essai',	'nowhere',	'1996-12-21',	'15:23:00',	'',	'Essai'),
(8,	'8522',	'ftgyhuji',	'2835-05-04',	'15:00:00',	'',	'fgtyhuji');

-- 2023-07-21 15:01:41
